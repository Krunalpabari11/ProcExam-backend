// import swaggerUi from 'swagger-ui-express';
// import yaml from 'yamljs';
// import path from 'path';

// const swaggerConfig = (app) => {
//     const swaggerDocument = yaml.load(path.join(__dirname, '../docs/swagger.yaml'));
    
//     app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
// };

// export default swaggerConfig;